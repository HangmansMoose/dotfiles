#!/usr/bin/env python3
"""Generate Notepad++ themes from the koda.nvim palettes.

Usage: python3 gen_koda_npp.py <stylers.model.xml> <koda palette dir> <out dir>
"""
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

BOLD, ITALIC, UNDERLINE = 1, 2, 4


def load_palette(path):
    pal = {}
    for k, v in re.findall(r'(\w+)\s*=\s*"(#[0-9a-fA-F]{6})"', Path(path).read_text()):
        pal[k] = v.lstrip("#").upper()
    return pal


def blend(fg, bg, alpha):
    """Same as koda's Utils.blend: alpha of fg over bg."""
    f = [int(fg[i:i + 2], 16) for i in (0, 2, 4)]
    b = [int(bg[i:i + 2], 16) for i in (0, 2, 4)]
    return "".join(f"{round(alpha * x + (1 - alpha) * y):02X}" for x, y in zip(f, b))


def has(name, *words):
    return any(w in name for w in words)


def classify(name, lexer):
    """Map a Notepad++ style name to (palette key, fontStyle) following koda's
    vim syntax / treesitter groups."""
    n = name.upper()

    # Search results panel
    if lexer == "searchResult":
        if n == "HIT WORD":
            return "highlight", BOLD
        if n == "SEARCH HEADER":
            return "emphasis", BOLD
        if n == "FILE HEADER":
            return "func", BOLD
        if n == "LINE NUMBER":
            return "comment", 0
        return "fg", 0

    if n in ("ADDED", "INSERTED") or n.startswith("ADDED"):
        return "success", 0
    if n in ("DELETED", "REMOVED", "REMOVED KEY"):
        return "danger", 0
    if n in ("CHANGED", "CHANGED KEY"):
        return "warning", 0
    if lexer == "diff" and n == "POSITION":
        return "info", 0
    if has(n, "TOO MANY", "ERROR", "ILLEGAL", "WRONG", "GARBAGE", "NOT CLOSED", "STRING EOL", "UNKNOWN OPCODE"):
        return "danger", 0
    if n.startswith("COMMENT DOC KEYWORD") or n == "DOCUMENTATION MACRO IN COMMENT":
        return "comment", BOLD
    if has(n, "COMMENT", "POD", "REM"):
        return "comment", 0
    # markup
    if re.fullmatch(r"H[1-6]|HEADER|TITLE|SECTION|SUBSECTION|MAIN SECTIONS|SUB SECTIONS", n):
        return "emphasis", BOLD
    if has(n, "URL", "URI", "LINK", "EMAIL"):
        return "info", UNDERLINE
    if has(n, "STRONG"):
        return "fg", BOLD
    if has(n, "EM1", "ITALIC"):
        return "fg", ITALIC
    if has(n, "EM2", "UNDERLINE"):
        return "fg", UNDERLINE
    if has(n, "ESCAPE", "SPECIAL CHAR", "FORMAT IDENTIFIER", "VAR IN", "SUBSTITUTION"):
        return "special", 0
    if n in ("CHARACTER", "CHAR", "F CHARACTER", "HERE CHARACTER"):
        return "char", 0
    if has(n, "STRING", "QUOTE", "HEREDOC", "HERE Q", "HERE DELIM", "VERBATIM", "CDATA",
           "BACKTICK", "TRIPLE", "REGEX", "LITERAL", "CODE", "MULTILINESTRING", "F TRIPLE"):
        return "string", 0
    if has(n, "NUMBER", "NUMERIC", "HEX", "BINNUMBER", "CONSTANT", "BOOLEAN", "NIL",
           "ENTITY", "MACRO", "MONEY", "TIME {", "PAIR (", "TUPLE ("):
        return "const", 0
    if has(n, "FUNCTION", "FUNC", "METHOD", "DEF NAME", "PROTOTYPE"):
        return "func", BOLD
    if has(n, "OPERATOR", "DELIMITER", "SYMBOL", "PUNCT", "BRACE", "PAREN", "ASSIGNMENT"):
        return "operator", 0
    if has(n, "CLASS NAME", "TYPE", "TYPEDEF", "STD PACKAGE", "MODULE NAME"):
        return "type", 0
    if has(n, "PREPROC", "DIRECTIVE", "PRAGMA", "INCLUDE", "IMPORT", "IFDEF", "IF DEFINE",
           "KEYWORD", "INSTRUCTION", "WORD", "STATEMENT", "RESERVED", "COMMAND", "TAG",
           "ATTRIBUTE", "LABEL", "USER", "OPCODE", "REGISTER", "SELECTOR", "PSEUDO",
           "IMPORTANT", "MEDIA", "SECTION", "KEY", "INSTR", "CONTROL", "TARGET", "RETURN"):
        return "keyword", 0
    if has(n, "VALUE"):
        return "string", 0
    if has(n, "SELF", "SUPER", "GLOBAL", "PREDEFINED", "ENVIRONMENT"):
        return "const", 0
    return "fg", 0


ANSI = {"BLACK": "bg", "RED": "danger", "GREEN": "success", "YELLOW": "warning",
        "BLUE": "info", "MAGENTA": "pink", "CYAN": "cyan", "WHITE": "fg", "DEFAULT": None}


def style_lexers(root, p):
    for lexer in root.iter("LexerType"):
        lname = lexer.get("name")
        for ws in lexer.iter("WordsStyle"):
            name = ws.get("name", "")
            m = re.fullmatch(r"(BOLD )?(\w+) on (\w+)", name, re.I)
            a = re.fullmatch(r"ANSI COLOR (.+)", name, re.I)
            if m and m.group(2).upper() in ANSI:  # ANSI-coloured output lexers
                fgk, bgk = ANSI[m.group(2).upper()], ANSI.get(m.group(3).upper())
                ws.set("fgColor", p[fgk] if fgk else p["fg"])
                ws.set("bgColor", p[bgk] if bgk else p["bg"])
                ws.set("fontStyle", "1" if m.group(1) else "0")
                continue
            if a:
                c = a.group(1).upper().replace("BRIGHT ", "")
                key = {"BROWN": "orange", "GRAY": "keyword", "DARK GRAY": "comment"}.get(c) or ANSI.get(c) or "fg"
                ws.set("fgColor", p[key])
                ws.set("bgColor", p["bg"])
                ws.set("fontStyle", "0")
                continue
            key, fs = classify(name, lname)
            ws.set("fgColor", p[key])
            ws.set("bgColor", p["bg"])
            ws.set("fontStyle", str(fs))
            ws.set("fontName", "")
            ws.set("fontSize", "")


def style_globals(root, p, dark):
    bg, fg, line = p["bg"], p["fg"], p["line"]
    sel = blend(p["highlight"], bg, 0.30)
    g = {
        "Default Style": dict(fgColor=fg, bgColor=bg, fontName="Consolas", fontStyle="0", fontSize="10"),
        "Indent guideline style": dict(fgColor=p["dim"], bgColor=bg),
        "Brace highlight style": dict(fgColor=p["special"], bgColor=line, fontStyle="1"),
        "Bad brace colour": dict(fgColor=p["danger"], bgColor=bg),
        "Current line background colour": dict(bgColor=line),
        "Selected text colour": dict(bgColor=sel, fgColor=fg),
        "Multi-selected text color": dict(bgColor=sel),
        "Caret colour": dict(fgColor=fg),
        "Multi-edit carets color": dict(fgColor=p["keyword"]),
        "Edge colour": dict(fgColor=line),
        "Line number margin": dict(fgColor=p["comment"], bgColor=bg),
        "Bookmark margin": dict(bgColor=bg),
        "Change History margin": dict(bgColor=bg),
        "Change History modified": dict(fgColor=p["warning"], bgColor=p["warning"]),
        "Change History revert modified": dict(fgColor=p["info"], bgColor=p["info"]),
        "Change History revert origin": dict(fgColor=p["cyan"], bgColor=p["cyan"]),
        "Change History saved": dict(fgColor=p["success"], bgColor=p["success"]),
        "Fold": dict(fgColor=p["dim"], bgColor=bg),
        "Fold active": dict(fgColor=p["fg"]),
        "Fold margin": dict(fgColor=bg, bgColor=bg),
        "White space symbol": dict(fgColor=p["dim"]),
        "Smart Highlighting": dict(bgColor=blend(p["highlight"], bg, 0.45)),
        "Find Mark Style": dict(bgColor=blend(p["danger"], bg, 0.45)),
        "Find status: Not found": dict(fgColor=p["danger"]),
        "Find status: Message": dict(fgColor=p["info"]),
        "Find status: Search end reached": dict(fgColor=p["success"]),
        "Mark Style 1": dict(bgColor=p["cyan"]),
        "Mark Style 2": dict(bgColor=p["orange"]),
        "Mark Style 3": dict(bgColor=p["warning"]),
        "Mark Style 4": dict(bgColor=p["pink"]),
        "Mark Style 5": dict(bgColor=p["green"]),
        "Incremental highlight all": dict(bgColor=p["highlight"]),
        "Tags match highlighting": dict(bgColor=blend(p["pink"], bg, 0.45)),
        "Tags attribute": dict(bgColor=blend(p["warning"], bg, 0.45)),
        "Active tab focused indicator": dict(fgColor=p["highlight"]),
        "Active tab unfocused indicator": dict(fgColor=p["dim"]),
        "Active tab text": dict(fgColor=fg),
        "Inactive tabs": dict(fgColor=p["comment"], bgColor=line),
        "URL hovered": dict(fgColor=p["info"]),
        "Document map": dict(fgColor=p["highlight"], bgColor=bg),
        "EOL custom color": dict(fgColor=p["dim"]),
        "Non-printing characters custom color": dict(fgColor=p["dim"]),
        "Global override": dict(fgColor=fg, bgColor=bg),
    }
    tabs = ["warning", "success", "info", "danger", "pink"]
    for i, k in enumerate(tabs, 1):
        g[f"Tab color {i}"] = dict(bgColor=blend(p[k], p["bg"] if not dark else "FFFFFF", 0.25))
        g[f"Tab color dark mode {i}"] = dict(bgColor=blend(p[k], "101010" if not dark else bg, 0.45))
    for ws in root.find("GlobalStyles").iter("WidgetStyle"):
        for attr, val in g.get(ws.get("name"), {}).items():
            ws.set(attr, val)


def main(model, paldir, outdir):
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    variants = {"dark": True, "moss": True, "light": False, "glade": False}
    for v, dark in variants.items():
        p = load_palette(Path(paldir) / f"{v}.lua")
        tree = ET.parse(model)
        root = tree.getroot()
        style_lexers(root, p)
        style_globals(root, p, dark)
        ET.indent(tree, space="    ")
        dest = out / f"Koda {v.capitalize()}.xml"
        with open(dest, "wb") as f:
            f.write(b'<?xml version="1.0" encoding="UTF-8" ?>\n')
            f.write(f"<!-- Koda {v.capitalize()} for Notepad++, ported from "
                    "https://github.com/oskarnurm/koda.nvim (MIT) -->\n".encode())
            tree.write(f, encoding="utf-8", xml_declaration=False)
        print("wrote", dest)


if __name__ == "__main__":
    main(*sys.argv[1:4])
